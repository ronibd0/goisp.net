<?php
    $name = $_POST['name'];
    $email = $_POST['email'];
    $message = $_POST['message'];

    $email_from = 'GO Internet Site';
    $email_subject = 'New Message From Go Contact';
    $email_body = "Name: $name.\n".
                  "Email: $email.\n".
                  "Message: $message.\n";
    
    $to ="support@goisp.net";
    $headers = "From: $email_from \r\n";
    $headers .="Reply-To: $email \r\n";

    mail($to,$emamil_subject,$email_body,$headers);

    header("location: index.html");




?>
